package reportRunner.Grafana;

import lombok.Data;


@Data
public class GraphPanel {
    private String panelId;
    private String panelName;
    private String application;
}
